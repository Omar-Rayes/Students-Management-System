﻿namespace Students_Mangement_System
{
    partial class Frm_Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.DGV_Registration = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.RText_Search = new System.Windows.Forms.RichTextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.Com_NameC = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.Btn_Delete = new System.Windows.Forms.Button();
            this.Btn_Update = new System.Windows.Forms.Button();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.DTP_history = new System.Windows.Forms.DateTimePicker();
            this.Com_NameS = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Lbl_Course = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.RText_SpecialC = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Lbl_Cost = new System.Windows.Forms.Label();
            this.RadBtn_Cost = new System.Windows.Forms.RadioButton();
            this.RadBtn_SepicalC = new System.Windows.Forms.RadioButton();
            this.RText_Cause = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Registration)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 9F);
            this.groupBox1.Location = new System.Drawing.Point(15, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1678, 684);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "معلومات التسجيل";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.32536F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.67464F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox4, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1672, 657);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(210)))), ((int)(((byte)(239)))));
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 8.6F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(858, 615);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "تفاصيل التسجيل";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 14F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.DGV_Registration, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.RText_Search, 1, 2);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.03943F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.90421F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1.066005F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.99036F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(852, 589);
            this.tableLayoutPanel3.TabIndex = 9;
            this.tableLayoutPanel3.TabStop = true;
            // 
            // DGV_Registration
            // 
            this.DGV_Registration.AllowUserToAddRows = false;
            this.DGV_Registration.AllowUserToDeleteRows = false;
            this.DGV_Registration.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Registration.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGV_Registration.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            this.DGV_Registration.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DGV_Registration.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel3.SetColumnSpan(this.DGV_Registration, 2);
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 8.6F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Registration.DefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_Registration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV_Registration.Location = new System.Drawing.Point(3, 224);
            this.DGV_Registration.MultiSelect = false;
            this.DGV_Registration.Name = "DGV_Registration";
            this.DGV_Registration.ReadOnly = true;
            this.DGV_Registration.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.6F, System.Drawing.FontStyle.Bold);
            this.DGV_Registration.RowTemplate.Height = 29;
            this.DGV_Registration.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Registration.Size = new System.Drawing.Size(832, 362);
            this.DGV_Registration.TabIndex = 32;
            this.DGV_Registration.TabStop = false;
            this.DGV_Registration.DoubleClick += new System.EventHandler(this.DGV_Registration_DoubleClick);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(584, 58);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(251, 23);
            this.label2.TabIndex = 33;
            this.label2.Text = "البحث حسب اسم الطالب أو الصف : ";
            // 
            // RText_Search
            // 
            this.RText_Search.Dock = System.Windows.Forms.DockStyle.Top;
            this.RText_Search.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RText_Search.Location = new System.Drawing.Point(507, 100);
            this.RText_Search.Name = "RText_Search";
            this.RText_Search.Size = new System.Drawing.Size(328, 33);
            this.RText_Search.TabIndex = 34;
            this.RText_Search.Tag = "";
            this.RText_Search.Text = "";
            this.RText_Search.TextChanged += new System.EventHandler(this.RText_Search_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(210)))), ((int)(((byte)(239)))));
            this.groupBox4.Controls.Add(this.tableLayoutPanel1);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 8.6F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(867, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(802, 615);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "بيانات التسجيل";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.03149F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.96851F));
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.Com_NameC, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label8, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label10, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.DTP_history, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.Com_NameS, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label12, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.Lbl_Course, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.groupBox3, 1, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.50591F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.8567F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.6998F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.02028F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(796, 589);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 10F);
            this.label7.Location = new System.Drawing.Point(595, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 23);
            this.label7.TabIndex = 35;
            this.label7.Text = "اختيار اسم الصف :";
            // 
            // Com_NameC
            // 
            this.Com_NameC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Com_NameC.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Com_NameC.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Com_NameC.Font = new System.Drawing.Font("Arial", 9F);
            this.Com_NameC.ForeColor = System.Drawing.Color.Black;
            this.Com_NameC.FormattingEnabled = true;
            this.Com_NameC.Location = new System.Drawing.Point(492, 209);
            this.Com_NameC.MaxDropDownItems = 5;
            this.Com_NameC.Name = "Com_NameC";
            this.Com_NameC.Size = new System.Drawing.Size(240, 29);
            this.Com_NameC.TabIndex = 2;
            this.Com_NameC.SelectedIndexChanged += new System.EventHandler(this.Com_NameC_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 3);
            this.panel1.Controls.Add(this.tableLayoutPanel6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 451);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(729, 135);
            this.panel1.TabIndex = 4;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel6.ColumnCount = 5;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Controls.Add(this.Btn_Reset, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.Btn_Delete, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.Btn_Update, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.Btn_Add, 0, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(726, 111);
            this.tableLayoutPanel6.TabIndex = 4;
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Btn_Reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.Btn_Reset.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.Btn_Reset.ForeColor = System.Drawing.Color.White;
            this.Btn_Reset.Location = new System.Drawing.Point(169, 36);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(134, 39);
            this.Btn_Reset.TabIndex = 8;
            this.Btn_Reset.Text = "جديد";
            this.Btn_Reset.UseVisualStyleBackColor = false;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // Btn_Delete
            // 
            this.Btn_Delete.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Btn_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.Btn_Delete.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.Btn_Delete.ForeColor = System.Drawing.Color.White;
            this.Btn_Delete.Location = new System.Drawing.Point(309, 36);
            this.Btn_Delete.Name = "Btn_Delete";
            this.Btn_Delete.Size = new System.Drawing.Size(134, 39);
            this.Btn_Delete.TabIndex = 7;
            this.Btn_Delete.Text = "حذف";
            this.Btn_Delete.UseVisualStyleBackColor = false;
            this.Btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // Btn_Update
            // 
            this.Btn_Update.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.Btn_Update.Enabled = false;
            this.Btn_Update.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.Btn_Update.ForeColor = System.Drawing.Color.White;
            this.Btn_Update.Location = new System.Drawing.Point(449, 36);
            this.Btn_Update.Name = "Btn_Update";
            this.Btn_Update.Size = new System.Drawing.Size(134, 39);
            this.Btn_Update.TabIndex = 6;
            this.Btn_Update.Text = "تعديل";
            this.Btn_Update.UseVisualStyleBackColor = false;
            this.Btn_Update.Click += new System.EventHandler(this.Btn_Update_Click);
            // 
            // Btn_Add
            // 
            this.Btn_Add.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.Btn_Add.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.Btn_Add.ForeColor = System.Drawing.Color.White;
            this.Btn_Add.Location = new System.Drawing.Point(589, 36);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(134, 39);
            this.Btn_Add.TabIndex = 4;
            this.Btn_Add.Text = "إضافة";
            this.Btn_Add.UseVisualStyleBackColor = false;
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 10F);
            this.label8.Location = new System.Drawing.Point(593, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 23);
            this.label8.TabIndex = 323;
            this.label8.Text = "اختيار اسم الطالب :";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Arial", 10F);
            this.label10.Location = new System.Drawing.Point(247, 50);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(114, 23);
            this.label10.TabIndex = 29;
            this.label10.Text = "تاريخ التسجيل :";
            // 
            // DTP_history
            // 
            this.DTP_history.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.DTP_history.Checked = false;
            this.DTP_history.CustomFormat = "";
            this.DTP_history.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_history.Location = new System.Drawing.Point(177, 102);
            this.DTP_history.Name = "DTP_history";
            this.DTP_history.Size = new System.Drawing.Size(184, 27);
            this.DTP_history.TabIndex = 4;
            this.DTP_history.TabStop = false;
            // 
            // Com_NameS
            // 
            this.Com_NameS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Com_NameS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Com_NameS.Font = new System.Drawing.Font("Arial", 9F);
            this.Com_NameS.ForeColor = System.Drawing.Color.Black;
            this.Com_NameS.FormattingEnabled = true;
            this.Com_NameS.Location = new System.Drawing.Point(402, 101);
            this.Com_NameS.MaxDropDownItems = 5;
            this.Com_NameS.Name = "Com_NameS";
            this.Com_NameS.Size = new System.Drawing.Size(330, 29);
            this.Com_NameS.TabIndex = 324;
            this.Com_NameS.SelectedIndexChanged += new System.EventHandler(this.Com_NameS_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Arial", 10F);
            this.label12.Location = new System.Drawing.Point(260, 159);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 23);
            this.label12.TabIndex = 5;
            this.label12.Text = "اسم الكورس :";
            // 
            // Lbl_Course
            // 
            this.Lbl_Course.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Lbl_Course.AutoSize = true;
            this.Lbl_Course.Font = new System.Drawing.Font("Arial", 10F);
            this.Lbl_Course.Location = new System.Drawing.Point(297, 212);
            this.Lbl_Course.Name = "Lbl_Course";
            this.Lbl_Course.Size = new System.Drawing.Size(64, 23);
            this.Lbl_Course.TabIndex = 325;
            this.Lbl_Course.Text = ". . . . .";
            // 
            // groupBox3
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.groupBox3, 3);
            this.groupBox3.Controls.Add(this.tableLayoutPanel5);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 268);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(729, 169);
            this.groupBox3.TabIndex = 328;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "المبلغ المطلوب";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 7;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.Lbl_Cost, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.RadBtn_Cost, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.RadBtn_SepicalC, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.RText_Cause, 6, 2);
            this.tableLayoutPanel5.Controls.Add(this.RText_SpecialC, 6, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 23);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 3;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(723, 143);
            this.tableLayoutPanel5.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10F);
            this.label1.Location = new System.Drawing.Point(576, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 23);
            this.label1.TabIndex = 331;
            this.label1.Text = " ل.س ";
            // 
            // RText_SpecialC
            // 
            this.RText_SpecialC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RText_SpecialC.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RText_SpecialC.Location = new System.Drawing.Point(-13, 68);
            this.RText_SpecialC.Multiline = false;
            this.RText_SpecialC.Name = "RText_SpecialC";
            this.RText_SpecialC.ReadOnly = true;
            this.RText_SpecialC.Size = new System.Drawing.Size(426, 28);
            this.RText_SpecialC.TabIndex = 330;
            this.RText_SpecialC.Tag = "";
            this.RText_SpecialC.Text = "";
            this.RText_SpecialC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.RText_SpecialC_KeyPress);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(568, 0);
            this.label5.Name = "label5";
            this.tableLayoutPanel5.SetRowSpan(this.label5, 3);
            this.label5.Size = new System.Drawing.Size(2, 143);
            this.label5.TabIndex = 326;
            // 
            // Lbl_Cost
            // 
            this.Lbl_Cost.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Lbl_Cost.AutoSize = true;
            this.Lbl_Cost.Font = new System.Drawing.Font("Arial", 10F);
            this.Lbl_Cost.Location = new System.Drawing.Point(636, 21);
            this.Lbl_Cost.Name = "Lbl_Cost";
            this.Lbl_Cost.Size = new System.Drawing.Size(64, 23);
            this.Lbl_Cost.TabIndex = 325;
            this.Lbl_Cost.Text = ". . . . .";
            // 
            // RadBtn_Cost
            // 
            this.RadBtn_Cost.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.RadBtn_Cost.AutoSize = true;
            this.RadBtn_Cost.BackColor = System.Drawing.Color.Transparent;
            this.RadBtn_Cost.Checked = true;
            this.RadBtn_Cost.Font = new System.Drawing.Font("Arial", 10F);
            this.RadBtn_Cost.Location = new System.Drawing.Point(419, 19);
            this.RadBtn_Cost.Name = "RadBtn_Cost";
            this.RadBtn_Cost.Size = new System.Drawing.Size(143, 27);
            this.RadBtn_Cost.TabIndex = 8;
            this.RadBtn_Cost.TabStop = true;
            this.RadBtn_Cost.Text = "المبلغ الافتراضي";
            this.RadBtn_Cost.UseVisualStyleBackColor = false;
            // 
            // RadBtn_SepicalC
            // 
            this.RadBtn_SepicalC.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RadBtn_SepicalC.AutoSize = true;
            this.RadBtn_SepicalC.Font = new System.Drawing.Font("Arial", 10F);
            this.RadBtn_SepicalC.Location = new System.Drawing.Point(308, 19);
            this.RadBtn_SepicalC.Name = "RadBtn_SepicalC";
            this.RadBtn_SepicalC.Size = new System.Drawing.Size(105, 27);
            this.RadBtn_SepicalC.TabIndex = 329;
            this.RadBtn_SepicalC.Text = "مبلغ خاص";
            this.RadBtn_SepicalC.UseVisualStyleBackColor = true;
            this.RadBtn_SepicalC.CheckedChanged += new System.EventHandler(this.RadBtn_SepicalC_CheckedChanged);
            // 
            // RText_Cause
            // 
            this.RText_Cause.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RText_Cause.Font = new System.Drawing.Font("Arial", 9F);
            this.RText_Cause.Location = new System.Drawing.Point(-13, 106);
            this.RText_Cause.Multiline = false;
            this.RText_Cause.Name = "RText_Cause";
            this.RText_Cause.ReadOnly = true;
            this.RText_Cause.Size = new System.Drawing.Size(426, 28);
            this.RText_Cause.TabIndex = 331;
            this.RText_Cause.Tag = "";
            this.RText_Cause.Text = "";
            // 
            // Frm_Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1709, 714);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Frm_Registration";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.Text = "تسجيل الطلاب";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frm_Registration_Load);
            this.SizeChanged += new System.EventHandler(this.Frm_Registration_SizeChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Frm_Registration_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Registration)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Com_NameC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker DTP_history;
        public System.Windows.Forms.ComboBox Com_NameS;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Button Btn_Reset;
        private System.Windows.Forms.Button Btn_Delete;
        private System.Windows.Forms.Button Btn_Update;
        private System.Windows.Forms.Button Btn_Add;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Lbl_Course;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Lbl_Cost;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.DataGridView DGV_Registration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox RText_Search;
        private System.Windows.Forms.RadioButton RadBtn_SepicalC;
        private System.Windows.Forms.RadioButton RadBtn_Cost;
        private System.Windows.Forms.RichTextBox RText_SpecialC;
        private System.Windows.Forms.RichTextBox RText_Cause;
    }
}