﻿namespace Students_Mangement_System
{
    partial class Frm_MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_MainForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Lbl_Time = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Pic_Box = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Lbl_Date = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Panel_Frm = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gradientPanel1 = new Students_Mangement_System.GradientPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.إدارةالكورساتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إدارةالصفوفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الجلساتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قسماالطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolMS_Students = new System.Windows.Forms.ToolStripMenuItem();
            this.تسجيلالطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.إدارةالمدفوعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المدفوعاتالسابقةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الإعداداتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolMS_Setting = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolMS_Users = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Box)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.gradientPanel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.Lbl_Time);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Lbl_Date);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1124, 144);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(364, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 29);
            this.label3.TabIndex = 4;
            this.label3.Text = "التاريخ :";
            // 
            // Lbl_Time
            // 
            this.Lbl_Time.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Lbl_Time.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Time.Location = new System.Drawing.Point(110, 76);
            this.Lbl_Time.Name = "Lbl_Time";
            this.Lbl_Time.Size = new System.Drawing.Size(248, 34);
            this.Lbl_Time.TabIndex = 7;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.4365F));
            this.tableLayoutPanel1.Controls.Add(this.Pic_Box, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(534, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(590, 144);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // Pic_Box
            // 
            this.Pic_Box.BackColor = System.Drawing.Color.White;
            this.Pic_Box.Cursor = System.Windows.Forms.Cursors.Default;
            this.Pic_Box.Image = ((System.Drawing.Image)(resources.GetObject("Pic_Box.Image")));
            this.Pic_Box.ImageLocation = "";
            this.Pic_Box.Location = new System.Drawing.Point(434, 3);
            this.Pic_Box.Name = "Pic_Box";
            this.tableLayoutPanel1.SetRowSpan(this.Pic_Box, 2);
            this.Pic_Box.Size = new System.Drawing.Size(119, 138);
            this.Pic_Box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_Box.TabIndex = 0;
            this.Pic_Box.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(93, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(335, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "          برنامج إدارة مكتب تعليمي";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Light", 8F);
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(63, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(365, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "                    توفير مستوى ممتاز في جميع مجالات التعليم...";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(364, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "الوقت  :";
            // 
            // Lbl_Date
            // 
            this.Lbl_Date.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Lbl_Date.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Date.Location = new System.Drawing.Point(110, 24);
            this.Lbl_Date.Name = "Lbl_Date";
            this.Lbl_Date.Size = new System.Drawing.Size(248, 34);
            this.Lbl_Date.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1124, 7);
            this.panel3.TabIndex = 4;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 564);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1124, 39);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Padding = new System.Windows.Forms.Padding(30, 10, 30, 0);
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(274, 34);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(274, 34);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BackColor = System.Drawing.Color.Transparent;
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(214, 34);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // Panel_Frm
            // 
            this.Panel_Frm.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Panel_Frm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Frm.Location = new System.Drawing.Point(0, 192);
            this.Panel_Frm.Name = "Panel_Frm";
            this.Panel_Frm.Size = new System.Drawing.Size(1124, 372);
            this.Panel_Frm.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.gradientPanel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 151);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1124, 41);
            this.panel2.TabIndex = 7;
            // 
            // gradientPanel1
            // 
            this.gradientPanel1.Angel = 0F;
            this.gradientPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.gradientPanel1.ColorButtom = System.Drawing.Color.Empty;
            this.gradientPanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(207)))), ((int)(((byte)(239)))));
            this.gradientPanel1.Controls.Add(this.menuStrip1);
            this.gradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.gradientPanel1.Name = "gradientPanel1";
            this.gradientPanel1.Size = new System.Drawing.Size(1124, 41);
            this.gradientPanel1.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.قسماالطلابToolStripMenuItem,
            this.toolStripMenuItem2,
            this.الإعداداتToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(91, -2);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(22, 2, 0, 2);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(927, 41);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إدارةالكورساتToolStripMenuItem,
            this.إدارةالصفوفToolStripMenuItem,
            this.الجلساتToolStripMenuItem});
            this.toolStripMenuItem1.Margin = new System.Windows.Forms.Padding(30, 0, 20, 0);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Padding = new System.Windows.Forms.Padding(35, 8, 4, 6);
            this.toolStripMenuItem1.Size = new System.Drawing.Size(144, 37);
            this.toolStripMenuItem1.Text = "قسم التعليم";
            // 
            // إدارةالكورساتToolStripMenuItem
            // 
            this.إدارةالكورساتToolStripMenuItem.Image = global::Students_Mangement_System.Properties.Resources.cursos_png_4;
            this.إدارةالكورساتToolStripMenuItem.Name = "إدارةالكورساتToolStripMenuItem";
            this.إدارةالكورساتToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.إدارةالكورساتToolStripMenuItem.Text = "إدارة الكورسات";
            this.إدارةالكورساتToolStripMenuItem.Click += new System.EventHandler(this.إدارةالكورساتToolStripMenuItem_Click);
            // 
            // إدارةالصفوفToolStripMenuItem
            // 
            this.إدارةالصفوفToolStripMenuItem.Image = global::Students_Mangement_System.Properties.Resources.flat_design_icon_of_classroom;
            this.إدارةالصفوفToolStripMenuItem.Name = "إدارةالصفوفToolStripMenuItem";
            this.إدارةالصفوفToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.إدارةالصفوفToolStripMenuItem.Text = "إدارة الصفوف";
            this.إدارةالصفوفToolStripMenuItem.Click += new System.EventHandler(this.إدارةالصفوفToolStripMenuItem_Click);
            // 
            // الجلساتToolStripMenuItem
            // 
            this.الجلساتToolStripMenuItem.Image = global::Students_Mangement_System.Properties.Resources.time_management_icon;
            this.الجلساتToolStripMenuItem.Name = "الجلساتToolStripMenuItem";
            this.الجلساتToolStripMenuItem.Size = new System.Drawing.Size(224, 30);
            this.الجلساتToolStripMenuItem.Text = "إدارة مواعيد الصف";
            this.الجلساتToolStripMenuItem.Click += new System.EventHandler(this.الجلساتToolStripMenuItem_Click);
            // 
            // قسماالطلابToolStripMenuItem
            // 
            this.قسماالطلابToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolMS_Students,
            this.تسجيلالطلابToolStripMenuItem});
            this.قسماالطلابToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.قسماالطلابToolStripMenuItem.Margin = new System.Windows.Forms.Padding(30, 0, -8, 0);
            this.قسماالطلابToolStripMenuItem.Name = "قسماالطلابToolStripMenuItem";
            this.قسماالطلابToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.قسماالطلابToolStripMenuItem.Size = new System.Drawing.Size(132, 37);
            this.قسماالطلابToolStripMenuItem.Text = "قسم الطلاب ";
            // 
            // ToolMS_Students
            // 
            this.ToolMS_Students.Image = global::Students_Mangement_System.Properties.Resources.add_user_icon_vector_26201329;
            this.ToolMS_Students.Name = "ToolMS_Students";
            this.ToolMS_Students.Size = new System.Drawing.Size(199, 30);
            this.ToolMS_Students.Text = "إدارة الطلاب ";
            this.ToolMS_Students.Click += new System.EventHandler(this.ToolMS_Students_Click);
            // 
            // تسجيلالطلابToolStripMenuItem
            // 
            this.تسجيلالطلابToolStripMenuItem.Image = global::Students_Mangement_System.Properties.Resources.inscripcion_png_2;
            this.تسجيلالطلابToolStripMenuItem.Name = "تسجيلالطلابToolStripMenuItem";
            this.تسجيلالطلابToolStripMenuItem.Size = new System.Drawing.Size(199, 30);
            this.تسجيلالطلابToolStripMenuItem.Text = "تسجيل الطلاب";
            this.تسجيلالطلابToolStripMenuItem.Click += new System.EventHandler(this.تسجيلالطلابToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.إدارةالمدفوعاتToolStripMenuItem,
            this.المدفوعاتالسابقةToolStripMenuItem});
            this.toolStripMenuItem2.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.toolStripMenuItem2.Size = new System.Drawing.Size(155, 37);
            this.toolStripMenuItem2.Text = "قسم المدفوعات";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // إدارةالمدفوعاتToolStripMenuItem
            // 
            this.إدارةالمدفوعاتToolStripMenuItem.Image = global::Students_Mangement_System.Properties.Resources.New_Payment;
            this.إدارةالمدفوعاتToolStripMenuItem.Name = "إدارةالمدفوعاتToolStripMenuItem";
            this.إدارةالمدفوعاتToolStripMenuItem.Size = new System.Drawing.Size(230, 30);
            this.إدارةالمدفوعاتToolStripMenuItem.Text = "إدارة المدفوعات";
            this.إدارةالمدفوعاتToolStripMenuItem.Click += new System.EventHandler(this.إدارةالمدفوعاتToolStripMenuItem_Click);
            // 
            // المدفوعاتالسابقةToolStripMenuItem
            // 
            this.المدفوعاتالسابقةToolStripMenuItem.Enabled = false;
            this.المدفوعاتالسابقةToolStripMenuItem.Image = global::Students_Mangement_System.Properties.Resources.payment;
            this.المدفوعاتالسابقةToolStripMenuItem.Name = "المدفوعاتالسابقةToolStripMenuItem";
            this.المدفوعاتالسابقةToolStripMenuItem.Size = new System.Drawing.Size(230, 30);
            this.المدفوعاتالسابقةToolStripMenuItem.Text = "المدفوعات السابقة";
            this.المدفوعاتالسابقةToolStripMenuItem.Click += new System.EventHandler(this.المدفوعاتالسابقةToolStripMenuItem_Click);
            // 
            // الإعداداتToolStripMenuItem
            // 
            this.الإعداداتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolMS_Setting,
            this.ToolMS_Users});
            this.الإعداداتToolStripMenuItem.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.الإعداداتToolStripMenuItem.Name = "الإعداداتToolStripMenuItem";
            this.الإعداداتToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.الإعداداتToolStripMenuItem.Size = new System.Drawing.Size(100, 37);
            this.الإعداداتToolStripMenuItem.Text = "الإعدادات";
            // 
            // ToolMS_Setting
            // 
            this.ToolMS_Setting.Image = global::Students_Mangement_System.Properties.Resources.logo_setting;
            this.ToolMS_Setting.Name = "ToolMS_Setting";
            this.ToolMS_Setting.Size = new System.Drawing.Size(223, 30);
            this.ToolMS_Setting.Text = "إعدادات البرنامج";
            this.ToolMS_Setting.Click += new System.EventHandler(this.ToolMS_Setting_Click);
            // 
            // ToolMS_Users
            // 
            this.ToolMS_Users.Image = global::Students_Mangement_System.Properties.Resources.System_users_svg;
            this.ToolMS_Users.Name = "ToolMS_Users";
            this.ToolMS_Users.Size = new System.Drawing.Size(223, 30);
            this.ToolMS_Users.Text = "إدارة المستخدمين";
            this.ToolMS_Users.Click += new System.EventHandler(this.ToolMS_Users_Click);
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Margin = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(72, 37);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // Frm_MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1124, 603);
            this.Controls.Add(this.Panel_Frm);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "Frm_MainForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "الواجهة الرئيسية";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Frm_MainForm_FormClosed);
            this.Load += new System.EventHandler(this.Frm_MainForm_Load);
            this.SizeChanged += new System.EventHandler(this.Frm_MainForm_SizeChanged);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Box)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.gradientPanel1.ResumeLayout(false);
            this.gradientPanel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label Lbl_Time;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        public System.Windows.Forms.PictureBox Pic_Box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label Lbl_Date;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.Panel Panel_Frm;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem قسماالطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolMS_Students;
        private System.Windows.Forms.ToolStripMenuItem الإعداداتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolMS_Setting;
        public System.Windows.Forms.ToolStripMenuItem ToolMS_Users;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private GradientPanel gradientPanel1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem إدارةالكورساتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إدارةالصفوفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الجلساتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem تسجيلالطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إدارةالمدفوعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المدفوعاتالسابقةToolStripMenuItem;
    }
}